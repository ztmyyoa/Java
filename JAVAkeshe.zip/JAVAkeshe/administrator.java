package JAVAkeshe;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.sql.Date;
/**
 * 管理员的信息类
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
public class administrator {
    private String ID;
    private String NAME;
    private String SEX;
    private String BUILD;
    private String PHONE;
}
