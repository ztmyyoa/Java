package JAVAkeshe;

import javafx.application.Platform;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.AnchorPane;

import javax.swing.*;
import java.sql.*;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
/**
 * 管理员信息控制器类，用于处理与管理员信息相关的界面逻辑和交互。
 */
public class admincontroler {

    @FXML
    private TableColumn<administrator, String> GBUILD;

    @FXML
    private TableColumn<administrator, String> GID;

    @FXML
    private TableColumn<administrator, String> GNAME;

    @FXML
    private TableColumn<administrator, String> GPHONE;

    @FXML
    private TableColumn<administrator, String> GSEX;
    @FXML
    private TableColumn<Student, String> STBED;

    @FXML
    private TableColumn<Student, String> STBUILD;

    @FXML
    private TableColumn<Student, String> STID;

    @FXML
    private TableColumn<Student, String> STNAME;

    @FXML
    private TableColumn<Student, String> STREPAIR;

    @FXML
    private TableColumn<Student, String> STROOM;

    @FXML
    private TableColumn<Student, String> STSEX;

    @FXML
    private Button check2;
    @FXML
    private Button adchange;

    @FXML
    private Button get;
    @FXML
    private Label adbuild;

    @FXML
    private Label adlabel;

    @FXML
    private Label adphone;

    @FXML
    private TableView<administrator> adview;

    @FXML
    private TextField cgbuild;

    @FXML
    private TextField cgid;

    @FXML
    private TextField cgname;

    @FXML
    private TextField cgphone;

    @FXML
    private TextField cgsex;
    @FXML
    private TextField cgbed;

    @FXML
    private Button change;
    @FXML
    private Button addst;
    @FXML
    private Button check1;

    @FXML
    private TextField gbuild;

    @FXML
    private TextField gid;

    @FXML
    private TextField gname;

    @FXML
    private TextField gphone;

    @FXML
    private TextField gsex;

    @FXML
    private Label id;

    @FXML
    private Button in;

    @FXML
    private Label name;

    @FXML
    private Button out;;

    @FXML
    private Button repair;

    @FXML
    private Button searchad;

    @FXML
    private Button searchst;

    @FXML
    private MenuItem delete;

    @FXML
    private MenuItem edit;
    @FXML
    private Label sex;
    @FXML
    private Label stbad;

    @FXML
    private Label stbuild;

    @FXML
    private Label stlabel;

    @FXML
    private Label stroom;
    @FXML
    private Button reset;
    @FXML
    private Button stchange;
    @FXML
    private TableView<Student> stview;
    @FXML
    private Button total;
    @FXML
    private TextField stmassage;
    @FXML
    private Button finishre;
    @FXML
    private Label strepair;
    @FXML
    private Label totallabel;
    @FXML
    private Pagination adpagetable;
    @FXML
    private TextArea totalmassage;
    private int itempage = 12;
    // 学生表初始更新的时间，设置为当前系统时间
    private Timestamp initialUpdateTime =
            Timestamp.valueOf(LocalDateTime.now());
    // 学生表最新更新时间，初始值与初始更新时间相同
    private Timestamp lastUpdateTime = initialUpdateTime;
    private String[] buildtosex=new String[12];
    /**
     * 根据楼栋索引设置 buildtosex 数组中的性别值。
     */
    private void setsex(){
        buildtosex[8]="男";
        buildtosex[9]="女";
        buildtosex[10]="男";
        buildtosex[11]="女";

    }
    /**
     * 显示与学生信息相关的组件。
     * 在切换到学生视图时调用此方法。
     */
    void setsttext() {//获取学生组件
        stinitializepage();
        stloadPageData(0);
        startPollingst();
        stlabel.setVisible(true);
        id.setVisible(true);
        cgid.setVisible(true);
        name.setVisible(true);
        cgname.setVisible(true);
        sex.setVisible(true);
        cgsex.setVisible(true);
        cgbuild.setVisible(true);
        stbuild.setVisible(true);
        stroom.setVisible(true);
        cgphone.setVisible(true);
        stbad.setVisible(true);
        cgbed.setVisible(true);
        check2.setVisible(true);
        stview.setVisible(true);
        adpagetable.setVisible(true);
        strepair.setVisible(true);
        stmassage.setVisible(true);
        edit.setVisible(true);
        delete.setVisible(true);
        addst.setVisible(true);

    }
    /**
     * 初始化 Controller，设置必要的组件和数据。
     * 当关联的 FXML 文件加载时，此方法将自动调用。
     *
     * @throws Exception 如果在初始化过程中发生错误。
     */
    @FXML
    private void initialize() throws Exception {//初始化
        setsex();
        settext();
        stview.getSelectionModel().setSelectionMode(SelectionMode.MULTIPLE);
        adinitializepage();
        String build = logincontroler.build1;
        gbuild.setText(build);
        gbuild.setDisable(true);
        adloadPageData(0);
    }
    /**
     * 清空组件。
     */
    private void settext() {//清空组件
        adlabel.setVisible(false);
        id.setVisible(false);
        cgid.setVisible(false);
        name.setVisible(false);
        cgname.setVisible(false);
        sex.setVisible(false);
        cgsex.setVisible(false);
        adbuild.setVisible(false);
        cgbuild.setVisible(false);
        adphone.setVisible(false);
        cgphone.setVisible(false);
        cgbed.setVisible(false);
        check1.setVisible(false);
        check2.setVisible(false);
        adview.setVisible(false);
        stview.setVisible(false);
        adpagetable.setVisible(false);
        stlabel.setVisible(false);
        stbuild.setVisible(false);
        stroom.setVisible(false);
        stbad.setVisible(false);
        stchange.setVisible(false);
        strepair.setVisible(false);
        stmassage.setVisible(false);
        edit.setVisible(false);
        delete.setVisible(false);
        totallabel.setVisible(false);
        finishre.setVisible(false);
        totalmassage.setVisible(false);
        addst.setVisible(false);
    }
    /**
     * 获取管理员信息按钮的事件处理方法，用于显示查询管理员信息的相关组件。
     */
    private void getsearchad() {//获取理员信息按钮的组件
        settext();
        adlabel.setVisible(true);
        id.setVisible(true);
        cgid.setVisible(true);
        name.setVisible(true);
        cgname.setVisible(true);
        sex.setVisible(true);
        cgsex.setVisible(true);
        adbuild.setVisible(true);
        cgbuild.setVisible(true);
        adphone.setVisible(true);
        cgphone.setVisible(true);
        check1.setVisible(true);
        adview.setVisible(true);
        adpagetable.setVisible(true);
    }
    /**
     * 重置管理员信息按钮的事件处理方法，用于清空并启用相关输入框。
     *
     * @param event 重置按钮触发的事件对象
     */
    @FXML
    void resetad(ActionEvent event) {//取消按钮
        gid.clear();
        gid.setDisable(false);
        gname.clear();
        gname.setDisable(false);
        gsex.clear();
        gsex.setDisable(false);
        gphone.clear();
        gphone.setDisable(false);
        reset.setVisible(false);
        get.setVisible(true);
    }
    /**
     * 获取管理员信息确认按钮的事件处理方法，用于根据管理员ID查询并显示管理员信息。
     *
     * @param event 确认按钮触发的事件对象
     */
    @FXML
    void getinformation(ActionEvent event) {//确认按钮
        if (gid != null) {

            try {
                administrator administrator = new administrator();
                adminDAO adminDAO = new adminDAO(DruidDataSourceUtil.getConnection());
                administrator = adminDAO.select(gid.getText());
                if (!administrator.getBUILD().equals(gbuild.getText())) {
                    showAlert("楼号不符合");
                } else {
                    gid.setDisable(true);
                    gname.setText(administrator.getNAME());
                    gname.setDisable(true);
                    gsex.setText(administrator.getSEX());
                    gsex.setDisable(true);
                    gphone.setText(administrator.getPHONE());
                    gphone.setDisable(true);
                    get.setVisible(false);
                    reset.setVisible(true);
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }
    /**
     * 管理宿舍床位按钮的事件处理方法，用于切换到学生信息管理视图。
     */
    @FXML
    void changes(ActionEvent event) {//管理宿舍床位按钮
        settext();
        setsttext();
        check2.setVisible(true);
        stchange.setVisible(true);
    }
    /**
     * 管理员信息查询按钮的事件处理方法，用于根据输入条件查询管理员信息。
     * 查询条件包括管理员ID、姓名、性别、楼号、电话号码。
     *
     * @param event 查询按钮触发的事件对象
     */
    @FXML
    void check(ActionEvent event) {//查找管理员信息
        String id = cgid.getText();
        String name = cgname.getText();
        String sex = cgsex.getText();
        String build = cgbuild.getText();
        String phone = cgphone.getText();
        try {
            adminDAO adminDAO = new adminDAO(DruidDataSourceUtil.getConnection());
            StringBuilder conditionsBuilder = new StringBuilder("1=1");
            if (id != null && !id.isEmpty()) {
                conditionsBuilder.append(" AND ID = '").append(id).append("'");
            }
            if (name != null && !name.isEmpty()) {
                conditionsBuilder.append(" AND NAME = '").append(name).append("'");
            }
            if (sex != null && !sex.isEmpty()) {
                conditionsBuilder.append(" AND SEX = '").append(sex).append("'");
            }

            if (build != null && !build.isEmpty()) {
                conditionsBuilder.append(" AND BUILD = '").append(build).append("'");
            }

            if (phone != null && !phone.isEmpty()) {
                conditionsBuilder.append(" AND PHONE = '").append(phone).append("'");
            }
            List<administrator> searchResult = adminDAO.selectByCondition(conditionsBuilder.toString());
            adview.getItems().clear();
            if (!searchResult.isEmpty()) {
                adinitpage(searchResult);
                int startindex=0;
                int endindex=Math.min(itempage,searchResult.size());
                ObservableList<administrator> administratorList = FXCollections.observableArrayList(searchResult.subList(startindex,endindex));
                adview.getItems().addAll(administratorList);
            } else {
                // 处理未找到符合条件的学生的情况
                showAlert("未找到符合条件的管理员");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
    /**
     * 学生信息查询按钮的事件处理方法，用于根据输入条件查询学生信息。
     * 查询条件包括学生ID、姓名、性别、楼号、房间号、床位号。
     *
     * @param event 查询按钮触发的事件对象
     */
    @FXML
    void checkst(ActionEvent event) {//查询学生信息
        String id = cgid.getText();
        String name = cgname.getText();
        String sex = cgsex.getText();
        String build = cgbuild.getText();
        String room = cgphone.getText();
        String bed = cgbed.getText();
        try {
            studentDAO studentDAO = new studentDAO(DruidDataSourceUtil.getConnection());
            StringBuilder conditionsBuilder = new StringBuilder();
            if (id != null && !id.isEmpty()) {
                conditionsBuilder.append("id like '%" + id + "%' AND ");
            }
            if (name != null && !name.isEmpty()) {
                conditionsBuilder.append("name like '%" + name + "%' AND ");
            }
            if (sex != null && !sex.isEmpty()) {
                conditionsBuilder.append("sex like '%" + sex + "%' AND ");
            }

            if (build != null && !build.isEmpty()) {
                conditionsBuilder.append("build like '%" + build + "%' AND ");
            }

            if (room != null && !room.isEmpty()) {
                conditionsBuilder.append("room like '%" + room + "%' AND ");
            }
            if (bed != null && !bed.isEmpty()) {
                conditionsBuilder.append("bed like '%" + bed + "%' AND ");
            }
            if (conditionsBuilder.length() > 0) {
                conditionsBuilder.setLength(conditionsBuilder.length() - 4);
            }
            System.out.println(conditionsBuilder);
            List<Student> searchResult = studentDAO.selectByCondition(conditionsBuilder.toString());
            stview.getItems().clear();
            if (!searchResult.isEmpty()) {
                stinitpage(searchResult);
                int startindex=0;
                int endindex=Math.min(itempage,searchResult.size());
                ObservableList<Student> studentsList = FXCollections.observableArrayList(searchResult.subList(startindex,endindex));
                stview.getItems().addAll(studentsList);
            } else {
                // 处理未找到符合条件的学生的情况
                showAlert("未找到符合条件的学生");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
    /**
     * 统计按钮的事件处理方法，用于统计学生和管理员相关信息并显示在界面上。
     *
     * @param event 统计按钮触发的事件对象
     */
    @FXML
    void gettotal(ActionEvent event) {//统计
        settext();
        totallabel.setVisible(true);
        totalmassage.setVisible(true);

        try(Connection connection= DruidDataSourceUtil.getConnection();){
            studentDAO studentDAO=new studentDAO(connection);
            adminDAO adminDAO=new adminDAO(connection);
            int totaladmin=adminDAO.gettotalRecords();
            int totalstudent=studentDAO.gettotalRecords();
            int buildstudent=studentDAO.countStudentsByBuilding(gbuild.getText());
            int buildadmin=adminDAO.countStudentsByBuilding(gbuild.getText());
            int buildre= studentDAO.countStudentsByrepair(gbuild.getText());
            int totalrepair=studentDAO.countStudentsWithRepair();
            totalmassage.setText("当前楼号："+gbuild.getText()+"\n");
            totalmassage.appendText("管理楼号总学生数："+buildstudent+"\n");
            totalmassage.appendText("管理楼号管理员数："+buildadmin+"\n");
            totalmassage.appendText("管理楼号报修数："+buildre+"\n");
            totalmassage.appendText("总学生数："+totalstudent+"\n");
            totalmassage.appendText("总管理员数："+totaladmin+"\n");
            totalmassage.appendText("总报修数："+totalrepair+"\n");


        }catch (Exception e){
            e.printStackTrace();
        }
    }
    /**
     * 完成报修按钮的事件处理方法，用于完成学生报修并更新相关信息。
     *
     * @param event 完成报修按钮触发的事件对象
     */
    @FXML
    void finishrepair(ActionEvent event) {//完成报修
        String id = cgid.getText();

        if (id != null) {
            Student selectedStudent = stview.getSelectionModel().getSelectedItem();
            String name = cgname.getText();
            String sex = cgsex.getText();
            String build = cgbuild.getText();
            String room = cgphone.getText();
            String bed = cgbed.getText();
            stmassage.setText("无");
            String massage = stmassage.getText();
            selectedStudent.setNAME(name);
            selectedStudent.setSEX(sex);
            selectedStudent.setBUILD(build);
            selectedStudent.setROOM(room);
            selectedStudent.setBED(bed);
            selectedStudent.setMASSAGE(massage);
            try (Connection connection = DruidDataSourceUtil.getConnection()) {
                studentDAO stDao = new studentDAO(connection);
                // 将更改保存到数据库
                stDao.updateByid(selectedStudent, id);
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }
    /**
     * 查看报修按钮的事件处理方法，用于查看当前存在报修情况的学生信息。
     * 显示已提交报修请求的学生列表。
     *
     * @param event 查看报修按钮触发的事件对象
     */
    @FXML
    void repairing(ActionEvent event) {//查看报修按钮
        settext();
        setsttext();
        finishre.setVisible(true);
        try {
            studentDAO studentDAO = new studentDAO(DruidDataSourceUtil.getConnection());
            StringBuilder conditionsBuilder = new StringBuilder("massage not like '无'");
            System.out.println(conditionsBuilder);
            List<Student> searchResult = studentDAO.selectByCondition(conditionsBuilder.toString());
            stview.getItems().clear();
            if (!searchResult.isEmpty()) {
                stinitpage(searchResult);
                int startindex=0;
                int endindex=Math.min(itempage,searchResult.size());
                ObservableList<Student> studentsList = FXCollections.observableArrayList(searchResult.subList(startindex,endindex));
                stview.getItems().addAll(studentsList);
            } else {
                // 处理未找到符合条件的学生的情况
                showAlert("未找到符合条件的学生");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
    /**
     * 查看管理员信息按钮的事件处理方法，用于查看管理员信息的界面组件。
     * 显示用于查询管理员信息的界面组件。
     *
     * @param event 查看管理员信息按钮触发的事件对象
     */
    @FXML
    void searchad(ActionEvent event) {
        settext();
        getsearchad();
    }
    /**
     * 查看学生按钮的事件处理方法，用于查看学生信息的界面组件。
     * 显示用于查询学生信息的界面组件，包括查询条件的输入框和查询按钮。
     *
     * @param event 查看学生按钮触发的事件对象
     */
    @FXML
    void searchst(ActionEvent event) {//查看学生按钮
        settext();
        setsttext();
        in.setVisible(true);
        out.setVisible(true);
    }
    /**
     * 学生信息修改按钮的事件处理方法，用于修改学生信息并更新数据库。
     *
     * @param event 学生信息修改按钮触发的事件对象
     */
    @FXML
    void stchange(ActionEvent event) {//修改信息
        String id = cgid.getText();
        String name = cgname.getText();
        String sex = cgsex.getText();
        String build = cgbuild.getText();
        String room = cgphone.getText();
        String bed = cgbed.getText();
        String massage = stmassage.getText();
        if (!Objects.equals(build, gbuild.getText())) {
            showAlert("无权限修改其他楼号");
        } else {
            Student selectedStudent = stview.getSelectionModel().getSelectedItem();
            selectedStudent.setNAME(name);
            selectedStudent.setSEX(sex);
            selectedStudent.setBUILD(build);
            selectedStudent.setROOM(room);
            selectedStudent.setBED(bed);
            selectedStudent.setMASSAGE(massage);
            try (Connection connection = DruidDataSourceUtil.getConnection()) {
                studentDAO stDao = new studentDAO(connection);
                // 将更改保存到数据库
                stDao.updateByid(selectedStudent, id);
            } catch (SQLException e) {
                e.printStackTrace();
            }
            stview.refresh();
            clearInputFields();
            stloadPageData(adpagetable.getCurrentPageIndex());
        }
    }
    /**
     * 删除学生按钮的事件处理方法，用于删除选定的学生信息。
     * 删除前验证是否有权限删除其他楼号的学生信息。
     *
     * @param event 删除学生按钮触发的事件对象
     */
    @FXML
    void DELETE(ActionEvent event) {
        Student student = stview.getSelectionModel().getSelectedItem();
        if (student != null) {
            if(Objects.equals(student.getBUILD(), gbuild.getText())) {
                try (Connection connection = DruidDataSourceUtil.getConnection()) {
                    studentDAO studentDAO = new studentDAO(connection);
                    studentDAO.delete(String.valueOf(student.getID()));
                    stloadPageData(adpagetable.getCurrentPageIndex());
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
            else{
                showAlert("无权限删除其他楼号");
            }
        } else {
            showAlert("请选择一个学生以执行删除操作。");
        }
    }

    /**
     * 编辑学生按钮的事件处理方法，用于编辑选定学生的信息。
     * 显示编辑学生信息的界面组件，加载选中学生的信息到输入框。
     *
     * @param event 编辑学生按钮触发的事件对象
     */
    @FXML
    void EDIT(ActionEvent event) {
        check2.setVisible(false);
        stchange.setVisible(true);
        Student student = stview.getSelectionModel().getSelectedItem();
        if (student != null) {
            cgid.setText(student.getID());
            cgname.setText(student.getNAME());
            cgsex.setText(student.getSEX());
            cgbuild.setText(student.getBUILD());
            cgphone.setText(student.getROOM());
            cgbed.setText(student.getBED());
            stmassage.setText(student.getMASSAGE());
            cgid.setDisable(true);
        }
    }
    /**
     * 初始化管理员表的分页信息。
     */
    private void adinitializepage() {//初始化管理员表
        adpagetable.setPageCount(adCalculatepageCount());
        adpagetable.currentPageIndexProperty().addListener((observable, oldValue, newValue) -> {
            adloadPageData(newValue.intValue());
        });
    }
    /**
     * 设置查询学生后的分页信息。
     *
     * @param students 查询结果的学生列表
     */
    private void stinitpage(List<Student> students) {//查询学生后的设置分页
        int pagecount = (int) Math.ceil((double) students.size() / itempage);
        adpagetable.setPageCount(pagecount);
        adpagetable.currentPageIndexProperty().addListener((observable, oldValue, newValue) -> {
            int page = newValue.intValue();
            int startIndex = page * itempage;
            System.out.println(startIndex);
            int endIndex = Math.min((page+1) * itempage, students.size());
            System.out.println(endIndex);
            // 获取当前页的学生数据
            if(startIndex<=endIndex&&startIndex<students.size()){
                List<Student> list=students.subList(startIndex,endIndex);
                System.out.println(list);
                stview.getItems().clear();
                stview.getItems().addAll(list);
                stview.refresh();
            }
        });
    }
    /**
     * 查询管理员后的设置分页信息。
     *
     * @param administrators 查询结果的管理员列表
     */
    private void adinitpage(List<administrator> administrators){//查询管理员后的设置分页
        int pagecount = (int) Math.ceil((double) administrators.size() / itempage);
        adpagetable.setPageCount(pagecount);
        adpagetable.currentPageIndexProperty().addListener((observable, oldValue, newValue) -> {
            int page = newValue.intValue();
            int startIndex = page * itempage;
            System.out.println(startIndex);
            int endIndex = Math.min((page+1) * itempage, administrators.size());
            System.out.println(endIndex);
            // 获取当前页的学生数据
            if(startIndex<=endIndex&&startIndex<administrators.size()){
                List<administrator> list=administrators.subList(startIndex,endIndex);
                System.out.println(list);
                adview.getItems().clear();
                adview.getItems().addAll(list);
                adview.refresh();
            }
        });
    }
    /**
     * 计算管理员表的总页数。
     *
     * @return 管理员表的总页数
     */
    private int adCalculatepageCount() {
        try (Connection connection = DruidDataSourceUtil.getConnection()) {
            adminDAO adminDAO = new adminDAO(connection);
            return (int) Math.ceil((double) adminDAO.gettotalRecords() / itempage);

        } catch (Exception e) {
            e.printStackTrace();
        }
        return 0;
    }
    /**
     * 加载指定页面的管理员表数据。
     *
     * @param pageindex 要加载的管理员表页面索引
     */
    private void adloadPageData(int pageindex) {
        try (Connection connection = DruidDataSourceUtil.getConnection()) {
            adminDAO adminDAO = new adminDAO(connection);
            List<administrator> pageData = adminDAO.selectPaged(pageindex, itempage);
            adupdateTableView(pageData);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    /**
     * 更新管理员表的显示。
     *
     * @param administrators 要更新到管理员表的数据列表
     */
     void adupdateTableView(List<administrator> administrators) {

        adview.getItems().setAll(administrators);
// 为每列设置单元格值工厂，以从管理员对象中获取属性值显示。
        GID.setCellValueFactory(new PropertyValueFactory<>
                ("ID"));
        GNAME.setCellValueFactory(new PropertyValueFactory<>
                ("NAME"));
        GSEX.setCellValueFactory(new PropertyValueFactory<>
                ("SEX"));
        GBUILD.setCellValueFactory(new PropertyValueFactory<>
                ("BUILD"));
        GPHONE.setCellValueFactory(new PropertyValueFactory<>
                ("PHONE"));
    }
    /**
     * 初始化学生表的分页信息。
     */
    private void stinitializepage() {//初始化学生表
        adpagetable.setPageCount(stCalculatepageCount());
        adpagetable.currentPageIndexProperty().addListener((observable, oldValue, newValue) -> {
            stloadPageData(newValue.intValue());
        });
    }
    /**
     * 计算学生表的总页数。
     *
     * @return 学生表的总页数
     */
    private int stCalculatepageCount() {
        try (Connection connection = DruidDataSourceUtil.getConnection()) {
            studentDAO stDao = new studentDAO(connection);
            return (int) Math.ceil((double) stDao.gettotalRecords() / itempage);

        } catch (Exception e) {
            e.printStackTrace();
        }
        return 0;
    }
    /**
     * 加载指定页面的学生表数据。
     *
     * @param pageindex 要加载的学生表页面索引
     */
    private void stloadPageData(int pageindex) {
        try (Connection connection = DruidDataSourceUtil.getConnection()) {
            studentDAO stDAO = new studentDAO(connection);
            List<Student> pageData = stDAO.selectPaged(pageindex, itempage);
            stupdateTableView(pageData);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    /**
     * 更新学生表的显示。
     *
     * @param students 要更新到学生表的数据列表
     */
    private void stupdateTableView(List<Student> students) {

        stview.getItems().setAll(students);
// 为每列设置单元格值工厂，以从学生对象中获取属性值显示。
        STID.setCellValueFactory(new PropertyValueFactory<>
                ("ID"));
        STNAME.setCellValueFactory(new PropertyValueFactory<>
                ("NAME"));
        STSEX.setCellValueFactory(new PropertyValueFactory<>
                ("SEX"));
        STBUILD.setCellValueFactory(new PropertyValueFactory<>
                ("BUILD"));
        STROOM.setCellValueFactory(new PropertyValueFactory<>
                ("ROOM"));
        STBED.setCellValueFactory(new PropertyValueFactory<>
                ("BED"));
        STREPAIR.setCellValueFactory(new PropertyValueFactory<>
                ("MASSAGE"));
    }
    /**
     * 清空输入字段。
     */
    void clearInputFields() {
        cgid.clear();
        cgname.clear();
        cgsex.clear();
        cgbuild.clear();
        cgphone.clear();
        cgbed.clear();
        stmassage.clear();
    }
    /**
     * 显示信息提示框。
     *
     * @param message 要显示的信息
     */
    private void showAlert(String message) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle("提示");
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }
    /**
     * 启动学生表的数据轮询。
     */
    private void startPollingst() {
// 创建一个新的任务，用于在后台线程中执行数据轮询逻辑
        Runnable dataPollingTask = () -> {
            while (true) {
// 检查是否有新的数据更新
                if (sthasNewUpdate()) {
// 如果检测到新的更新，刷新用户界面
                    refreshUI();
// 更新初始的更新时间，用于跟踪数据更新的时间戳
                    initialUpdateTime = lastUpdateTime;
                }
                try {
// 休眠5秒钟后再次检查是否有新的数据更新
                    Thread.sleep(3000); // 休眠5秒钟（5000毫秒）
                } catch (InterruptedException e) {
                    e.printStackTrace(); // 如果线程被中断，打印异常堆栈信息
                }
            }
        };
// 创建一个新的线程执行上面定义的任务
        Thread dataPollingThread = new Thread(dataPollingTask);
// 设置该线程为守护线程，当应用关闭时，该线程会自动结束，不会阻止应用退出
        dataPollingThread.setDaemon(true);
// 启动新创建的线程来执行数据轮询任务
        dataPollingThread.start();
    }

    /**
     * 检查学生表是否有新的更新。
     *
     * @return 如果有新的更新，则返回 true；否则返回 false。
     */
    private boolean sthasNewUpdate() {// 判断是否有新的更新
// 从数据库服务中获取最新的更新时间
        try (Connection connection = DruidDataSourceUtil.getConnection()) {
            studentDAO studentDAO = new studentDAO(connection);
            lastUpdateTime = studentDAO.getUpdateTime();
// 判断获取到的最新更新时间是否不为空，并且与初始的更新时间不同
            return lastUpdateTime != null && !lastUpdateTime.equals(initialUpdateTime);

        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }
    /**
     * 刷新用户界面的方法。
     */
    private void refreshUI() {
// 使用JavaFX的Platform.runLater方法来确保UI更新的线程安全
        Platform.runLater(() -> {
// 加载当前页面的数据
            stloadPageData(0);
            System.out.println(111);
            adloadPageData(adpagetable.getCurrentPageIndex());
        });
    }
    /**
     * 当 UI 中的“添加”按钮被点击时处理事件。
     *
     * @param event 由“添加”按钮触发的 ActionEvent。
     */
    @FXML
    void add(ActionEvent event) {
        String id=cgid.getText();
        String name=cgname.getText();
        String sex=cgsex.getText();
        String build = cgbuild.getText();
        String room = cgphone.getText();
        String bed = cgbed.getText();
        if (id != null && !id.isEmpty()) {
            try (Connection connection = DruidDataSourceUtil.getConnection()) {
                studentDAO stDAO = new studentDAO(connection);
                Student student = stDAO.select(id);

                // 清空表格视图
                stview.getItems().clear();
                if(!Objects.equals(cgbuild.getText(), gbuild.getText())){
                    showAlert("无权限修改其他楼号");
                }
                else if (student == null) {// 判断学号是否存在
                    if(!Objects.equals(buildtosex[Integer.parseInt(gbuild.getText())],cgsex)){
                        showAlert("同一楼号只能出现一个性别");
                    }else {
                        //判断床位是否有人
                        try {
                            // 创建 studentDAO 对象
                            studentDAO studentDAO = new studentDAO(DruidDataSourceUtil.getConnection());

                            // 构建查询条件字符串
                            StringBuilder conditionsBuilder = new StringBuilder("1=1");

                            if (build != null && !build.isEmpty()) {
                                conditionsBuilder.append(" AND BUILD = '").append(build).append("'");
                            }

                            if (room != null && !room.isEmpty()) {
                                conditionsBuilder.append(" AND ROOM = '").append(room).append("'");
                            }

                            if (bed != null && !bed.isEmpty()) {
                                conditionsBuilder.append(" AND BED = '").append(bed).append("'");
                            }
                            // 获取符合条件的学生列表
                            List<Student> searchResults = studentDAO.selectByCondition(conditionsBuilder.toString());
                            // 清空表格视图
                            stview.getItems().clear();
                            //对应床位有人则显示信息
                            if (!searchResults.isEmpty()) {
                                ObservableList<Student> studentList = FXCollections.observableArrayList(searchResults);
                                stupdateTableView(studentList);
                                System.out.println(studentList);
                                showAlert("床位已经有学生");
                            } else {
                                //反之则插入信息
                                String massage = stmassage.getText();
                                Student newstudent = new Student(id, name, sex, build, room, bed, massage);
                                try (Connection connection1 = DruidDataSourceUtil.getConnection()) {
                                    studentDAO stDao = new studentDAO(connection1);
                                    stDao.insert(newstudent);
                                } catch (Exception e) {
                                    e.printStackTrace();
                                }
                                stloadPageData(0);

                            }
                        } catch (SQLException e) {
                            e.printStackTrace();
                            // 处理异常
                        }
                    }
                } else {
                    ObservableList<Student> studentList = FXCollections.observableArrayList(student);
                    stupdateTableView(studentList);
                    showAlert(id + "的学生已存在");
                }
            } catch (Exception e) {
                e.printStackTrace();
                // 处理异常
            }
        } else {
            showAlert("请输入学生ID");
        }
    }
    /**
     * 当 UI 中的“导入”按钮被点击时处理事件。
     *
     * @param event 由“导入”按钮触发的 ActionEvent。
     */
    @FXML
    void handin(ActionEvent event) {
        List<Student> students=new ArrayList<>();
        try (Connection connection= DruidDataSourceUtil.getConnection()){
            studentDAO studentDAO=new studentDAO(connection);
            JFileChooser fileChooser =new JFileChooser();
            int returnValue =fileChooser.showSaveDialog(null);
            if(returnValue == JFileChooser.APPROVE_OPTION){
                String filePath =fileChooser.getSelectedFile().getPath();
                students=EasyExcelUtil.readFromFileUsingEasyExcel(filePath,Student.class,"UTF-8");
               studentDAO.insertBatch(students);
                stloadPageData(0);
            }

        }catch (Exception e){
            e.printStackTrace();
        }

    }
    /**
     * 当 UI 中的“导出”按钮被点击时处理事件。
     *
     * @param event 由“导出”按钮触发的 ActionEvent。
     */
    @FXML
    void handout(ActionEvent event) {
        List<Student> students = new ArrayList<>();
        try (Connection connection = DruidDataSourceUtil.getConnection()) {
            studentDAO studentDAO = new studentDAO(connection);
            students=studentDAO.selectAll();
            JFileChooser fileChooser = new JFileChooser();
            int returnValue = fileChooser.showSaveDialog(null);
            if (returnValue == JFileChooser.APPROVE_OPTION) {
                String filePath = fileChooser.getSelectedFile().getPath();
                EasyExcelUtil.writeToFileUsingEasyExcel(students, filePath, Student.class, "UTF-8");
            }
        }catch (Exception e){
            e.printStackTrace();
        }
    }
    /**
     * 当 UI 中的“管理员修改”按钮被点击时处理事件。
     *
     * @param event 由“管理员修改”按钮触发的 ActionEvent。
     */
    @FXML
    void adchange(ActionEvent event) {
        String pid= gid.getText();
        gid.setDisable(false);
        gname.setDisable(false);
        gbuild.setDisable(false);
        gsex.setDisable(false);
        gphone.setDisable(false);
        String id = gid.getText();
        String name = gname.getText();
        String sex = gsex.getText();
        String build = gbuild.getText();
        String phone = gphone.getText();
        administrator admin=new administrator();
        admin.setID(id);
        admin.setNAME(name);
        admin.setSEX(sex);
        admin.setBUILD(build);
        admin.setPHONE(phone);
            try (Connection connection = DruidDataSourceUtil.getConnection()) {
                adminDAO adminDAO = new adminDAO(connection);
                // 将更改保存到数据库
                adminDAO.updateByid(admin, pid);
            } catch (SQLException e) {
                e.printStackTrace();
        }
        adview.refresh();
        adloadPageData(adpagetable.getCurrentPageIndex());
    }
}
