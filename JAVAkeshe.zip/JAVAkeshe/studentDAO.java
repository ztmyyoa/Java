package JAVAkeshe;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;
/**
 * 学生数据访问对象类，实现了JDBCO接口
 */
public class studentDAO implements JDBCO<Student,String>{
    private final String insert = "INSERT INTO dormitory (ID, NAME,SEX,BUILD,ROOM,BED,MASSAGE) VALUES (?, ?, ?, ?, ?, ?, ?)";
    private final String update1 ="UPDATE dormitory SET NAME=?,SEX=? ,BUILD=?, ROOM=?, BED=?, MASSAGE=? WHERE ID=?";
    private final String delete="DELETE FROM dormitory WHERE ID=?";

    public studentDAO(Connection connection) {
    }
    /**
     * 插入学生信息到数据库
     *
     * @param entity 学生实体对象
     * @throws SQLException SQL异常
     */
    @Override
    public void insert(Student entity) throws SQLException {
        try(Connection connection= DruidDataSourceUtil.getConnection();
        PreparedStatement preparedStatement=connection.prepareStatement(insert)){
            preparedStatement.setString(1,entity.getID());
            preparedStatement.setString(2,entity.getNAME());
            preparedStatement.setString(3,entity.getSEX());
            preparedStatement.setString(4,entity.getBUILD());
            preparedStatement.setString(5,entity.getROOM());
            preparedStatement.setString(6,entity.getBED());
            preparedStatement.setString(7,entity.getMASSAGE());
            preparedStatement.executeUpdate();
        }
    }
    /**
     * 批量插入学生信息到数据库
     *
     * @param  entity 学生实体对象列表
     * @throws SQLException SQL异常
     */
    @Override
    public void insertBatch(List<Student> entity) throws SQLException {
        try (Connection connection=DruidDataSourceUtil.getConnection();
        PreparedStatement preparedStatement=connection.prepareStatement(insert)){
            for (Student student:entity){
                preparedStatement.setString(1,student.getID());
                preparedStatement.setString(2,student.getNAME());
                preparedStatement.setString(3,student.getSEX());
                preparedStatement.setString(4,student.getBUILD());
                preparedStatement.setString(5,student.getROOM());
                preparedStatement.setString(6,student.getBED());
                preparedStatement.setString(7,student.getMASSAGE());
                preparedStatement.executeUpdate();
            }
        }
    }
    /**
     * 更新学生信息通过学生ID
     *
     * @param entity     学生实体对象
     * @param primaryKey 学生ID
     * @throws SQLException SQL异常
     */
    @Override
    public void updateByid(Student entity, String primaryKey) throws SQLException {
        String updateQuery = "UPDATE dormitory SET NAME=?, SEX=?, BUILD=?, ROOM=?, BED=?, MASSAGE=? WHERE ID=?";

        try (Connection connection = DruidDataSourceUtil.getConnection();
             PreparedStatement preparedStatement = connection.prepareStatement(updateQuery)) {

            // 设置更新语句中的参数
            preparedStatement.setString(1, entity.getNAME());
            preparedStatement.setString(2, entity.getSEX());
            preparedStatement.setString(3, entity.getBUILD());
            preparedStatement.setString(4, entity.getROOM());
            preparedStatement.setString(5, entity.getBED());
            preparedStatement.setString(6, entity.getMASSAGE());
            preparedStatement.setString(7, primaryKey);  // 使用学生ID作为更新的条件

            // 执行更新操作
            preparedStatement.executeUpdate();
        }
    }



    /**
     * 通过学生ID删除学生信息
     *
     * @param primaryKey 学生ID
     * @throws SQLException SQL异常
     */
    @Override
    public void delete(String primaryKey) throws SQLException {
        try (Connection connection=DruidDataSourceUtil.getConnection();
        PreparedStatement preparedStatement= connection.prepareStatement(delete)){
            preparedStatement.setString(1,primaryKey);
            preparedStatement.executeUpdate();

        }
    }

    /**
     * 通过学生ID查询学生信息
     *
     * @param primaryKey 学生ID
     * @return 学生实体对象
     * @throws SQLException SQL异常
     */
    @Override
    public Student select(String primaryKey) throws SQLException {
        Student student = null;

        try (Connection connection = DruidDataSourceUtil.getConnection();
             PreparedStatement preparedStatement = connection.prepareStatement("SELECT * FROM dormitory WHERE ID = ?");
        ) {
            preparedStatement.setString(1, primaryKey);

            try (ResultSet resultSet = preparedStatement.executeQuery()) {
                if (resultSet.next()) {
                    student = new Student();
                    student.setID(resultSet.getString("ID"));
                    student.setNAME(resultSet.getString("NAME"));
                    student.setSEX(resultSet.getString("SEX"));
                    student.setBUILD(resultSet.getString("BUILD"));
                    student.setROOM(resultSet.getString("ROOM"));
                    student.setBED(resultSet.getString("BED"));
                    student.setMASSAGE(resultSet.getString("MASSAGE"));
                }
            }
        }

        return student;
    }

    /**
     * 查询所有学生信息
     *
     * @return 学生实体对象列表
     * @throws SQLException SQL异常
     */
    @Override
    public List<Student> selectAll() throws SQLException {
        List<Student> students = new ArrayList<>();

        try (Connection connection = DruidDataSourceUtil.getConnection();
             PreparedStatement preparedStatement = connection.prepareStatement("SELECT * FROM dormitory");
             ResultSet resultSet = preparedStatement.executeQuery()) {
            int n=0;
            while (resultSet.next()) {
                Student student = new Student();
                student.setID(resultSet.getString("ID"));
                student.setNAME(resultSet.getString("NAME"));
                student.setSEX(resultSet.getString("SEX"));
                student.setBUILD(resultSet.getString("BUILD"));
                student.setROOM(resultSet.getString("ROOM"));
                student.setBED(resultSet.getString("BED"));
                student.setMASSAGE(resultSet.getString("MASSAGE"));
                students.add(student);

                n++;
            }
            System.out.println(n);
        }

        return students;
    }
    /**
     * 根据条件查询学生信息
     *
     * @param conditions 查询条件
     * @return 学生实体对象列表
     * @throws SQLException SQL异常
     */
    @Override
    public List<Student> selectByCondition(String conditions) throws SQLException {
        List<Student> students = new ArrayList<>();

        // 根据你的实际表结构进行调整
        String query = "SELECT * FROM dormitory WHERE " + conditions;

        try (Connection connection = DruidDataSourceUtil.getConnection();
             PreparedStatement statement = connection.prepareStatement(query);
             ResultSet resultSet = statement.executeQuery()) {
            System.out.println("SQL Query: " + query);
            while (resultSet.next()) {
                // 假设你的 Student 类有相应的构造函数
                Student student = new Student(
                        resultSet.getString("ID"),
                        resultSet.getString("NAME"),
                        resultSet.getString("SEX"),
                        resultSet.getString("BUILD"),
                        resultSet.getString("ROOM"),
                        resultSet.getString("BED"),
                        resultSet.getString("MASSAGE")
                );
                students.add(student);
            }
        }

        return students;
    }
    /**
     * 分页查询学生信息
     *
     * @param page     页码
     * @param pagesize 每页记录数
     * @return 学生实体对象列表
     * @throws SQLException SQL异常
     */
    @Override
    public List<Student> selectPaged(int page, int pagesize) throws SQLException {
        List<Student> students = new ArrayList<>();

        try (Connection connection = DruidDataSourceUtil.getConnection();
             PreparedStatement preparedStatement = connection.prepareStatement(
                     "SELECT * FROM dormitory LIMIT ?, ?");
        ) {
            int offset = page * pagesize;
            preparedStatement.setInt(1, offset);
            preparedStatement.setInt(2, pagesize);

            try (ResultSet resultSet = preparedStatement.executeQuery()) {
                while (resultSet.next()) {
                    Student student = new Student();
                    student.setID(resultSet.getString("ID"));
                    student.setNAME(resultSet.getString("NAME"));
                    student.setSEX(resultSet.getString("SEX"));
                    student.setBUILD(resultSet.getString("BUILD"));
                    student.setROOM(resultSet.getString("ROOM"));
                    student.setBED(resultSet.getString("BED"));
                    student.setMASSAGE(resultSet.getString("MASSAGE"));
                    students.add(student);
                }
            }
        }

        return students;
    }
    /**
     * 统计学生数量的相关操作
     */
    @Override
    public int countStudentsByBuilding(String building) throws SQLException {
        int count = 0;
        String sql = "SELECT COUNT(*) FROM dormitory WHERE BUILD = ?";

        try (Connection connection=DruidDataSourceUtil.getConnection();
                PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setString(1, building);

            try (ResultSet resultSet = statement.executeQuery()) {
                if (resultSet.next()) {
                    count = resultSet.getInt(1);
                }
            }
        }

        return count;
    }
    /**
     * 统计需要维修的学生数量
     *
     * @param building 宿舍楼号
     * @return 需要维修的学生数量
     * @throws SQLException SQL异常
     */
    public int countStudentsByrepair(String building) throws SQLException {
        int count = 0;
        String sql = "SELECT COUNT(*) FROM dormitory WHERE BUILD = ? AND MASSAGE not like '无'";

        try (Connection connection=DruidDataSourceUtil.getConnection();
             PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setString(1, building);

            try (ResultSet resultSet = statement.executeQuery()) {
                if (resultSet.next()) {
                    count = resultSet.getInt(1);
                }
            }
        }

        return count;
    }
    /**
     * 统计所有需要维修的学生数量
     *
     * @return 需要维修的学生数量
     * @throws SQLException SQL异常
     */
    public int countStudentsWithRepair() throws SQLException {
        int count = 0;
        String sql = "SELECT COUNT(*) FROM dormitory WHERE massage not like '无'";

        try (   Connection connection=DruidDataSourceUtil.getConnection();
                PreparedStatement statement = connection.prepareStatement(sql);
             ResultSet resultSet = statement.executeQuery()) {
            if (resultSet.next()) {
                count = resultSet.getInt(1);
            }
        }

        return count;
    }
    /**
     * 获取学生记录的总数
     *
     * @return 学生记录的总数
     * @throws Exception 异常
     */
    @Override
    public  int gettotalRecords() throws Exception {
        String sql="SELECT COUNT(*) FROM dormitory";
        try(Connection connection=DruidDataSourceUtil.getConnection();
            PreparedStatement preparedStatement= connection.prepareStatement(sql);
            ResultSet rs=preparedStatement.executeQuery()) {
            if(rs.next()){
                return rs.getInt(1);
            }
        }
        return 0;
    }
    /**
     * 获取更新时间戳
     *
     * @return 更新时间戳
     * @throws SQLException SQL异常
     */
    public Timestamp getUpdateTime() throws SQLException {
        String sql = "SELECT * FROM update_stu WHERE id = 1";
        try (Connection connection=DruidDataSourceUtil.getConnection();
                PreparedStatement preparedStatement = connection.prepareStatement(sql))
        {
            ResultSet rs = preparedStatement.executeQuery();
            if (rs.next()) {
                return rs.getTimestamp("updatetime");
            }
            return null;
        }
    }
    @Override
    public void updateByCondition(String condition, Object[] params, Student entity) throws SQLException {

    }
    @Override
    public void deleteBatch(List<String> primaryKeys) throws SQLException {

    }


    @Override
    public void deleteByCondition(String condition, Object[] params) throws SQLException {

    }


}
