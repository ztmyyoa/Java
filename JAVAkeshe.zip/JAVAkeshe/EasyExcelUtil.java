package JAVAkeshe;

import com.alibaba.excel.EasyExcel;
import com.alibaba.excel.ExcelReader;
import com.alibaba.excel.ExcelWriter;
import com.alibaba.excel.read.metadata.ReadSheet;
import com.alibaba.excel.write.metadata.WriteSheet;

import java.util.ArrayList;
import java.util.List;
/**
 * EasyExcel工具类，用于通过EasyExcel实现Excel文件的读写操作。
 */
public class EasyExcelUtil {
    /**
     * 使用EasyExcel将数据写入Excel文件。
     *
     * @param data      要写入的数据列表
     * @param filePath  目标文件路径
     * @param clazz     数据对象的Class类型
     * @param encoding  文件编码方式
     */
    public static void writeToFileUsingEasyExcel(List<Student> data, String filePath, Class<Student> clazz, String encoding) {
        // 创建 ExcelWriter 对象，省略部分代码...

        try {
            // 设置写入文件的编码方式
            ExcelWriter excelWriter = EasyExcel.write(filePath, clazz).build();
            WriteSheet writeSheet = EasyExcel.writerSheet("Sheet1").build();
            excelWriter.write(data, writeSheet);
            // finish 写入，刷新资源，关闭流
            excelWriter.finish();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /**
     * 使用EasyExcel从Excel文件中读取数据。
     *
     * @param filePath  Excel文件路径
     * @param clazz     数据对象的Class类型
     * @param encoding  文件编码方式
     * @return 读取的数据列表
     */
    public static List<Student> readFromFileUsingEasyExcel(String filePath, Class<Student> clazz, String encoding) {
        List<Student> dataList = new ArrayList<>();

        try {
            // 创建读取文件的 ExcelReader 对象，设置编码方式
            ExcelReader excelReader = EasyExcel.read(filePath, clazz, new ExcelListener(dataList)).build();
            ReadSheet readSheet = EasyExcel.readSheet(0).build();
            excelReader.read(readSheet);
            // 关闭读取流
            excelReader.finish();
        } catch (Exception e) {
            e.printStackTrace();
        }

        return dataList;
    }
}