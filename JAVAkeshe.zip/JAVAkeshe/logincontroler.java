package JAVAkeshe;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

import java.sql.Connection;

/**
 * 登录界面的控制器类
 */
public class logincontroler {
    @FXML
    private Button guan;
    @FXML
    private TextField build;
    @FXML
    private PasswordField password;
    @FXML
    private Button st;
    @FXML
    private TextField user;

    // 保存输入的宿舍楼信息
    public static String build1;

    /**
     * 处理管理员登录按钮的事件
     *
     * @param event 管理员登录按钮的事件
     */
    @FXML
    void guanli(ActionEvent event) {
        String username1 = user.getText();
        String password1 = password.getText();
        build1 = build.getText();
        try (Connection connection = DruidDataSourceUtil.getConnection()) {
            // 创建用户数据访问对象
            userDAO userDAO1 = new userDAO(connection);
            // 查询用户信息
            user user1 = userDAO1.select(username1);
            if (user1 == null) {
                showAlert("用户名不存在");
            } else {
                if (password1.equals(user1.getPassword())) {
                    // 登录成功，更新用户的宿舍楼信息
                    showAlert("登入成功");
                    user1.setBuild(build1);
                    System.out.println(user1);
                    userDAO1.updateByid(user1, username1);

                    // 打开管理员界面
                    Parent root = FXMLLoader.load(getClass().getResource("/javakeshe/admin.fxml"));
                    Stage stage = new Stage();
                    stage.setTitle("管理员端宿舍系统");
                    stage.setScene(new Scene(root));
                    stage.setResizable(false);
                    stage.show();
                } else {
                    showAlert("密码错误");
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /**
     * 处理学生登录按钮的事件
     *
     * @param event 学生登录按钮的事件
     */
    @FXML
    void student(ActionEvent event) {
        String username1 = user.getText();
        String password1 = password.getText();
        try (Connection connection = DruidDataSourceUtil.getConnection()) {
            // 创建用户数据访问对象
            userDAO userDAO1 = new userDAO(connection);
            // 查询用户信息
            user user1 = userDAO1.select(username1);
            if (user1 == null) {
                showAlert("用户名不存在");
            } else {
                if (password1.equals(user1.getPassword())) {
                    // 登录成功，打开学生界面
                    showAlert("登入成功");
                    Parent root = FXMLLoader.load(getClass().getResource("/javakeshe/student.fxml"));
                    Stage stage = new Stage();
                    stage.setTitle("学生端宿舍系统");
                    stage.setScene(new Scene(root));
                    stage.setResizable(false);
                    stage.show();
                } else {
                    showAlert("密码错误");
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /**
     * 弹出提示框
     *
     * @param message 提示信息
     */
    private void showAlert(String message) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle("提示");
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }
}
