package JAVAkeshe;


import javafx.application.Platform;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.AnchorPane;
import org.apache.commons.lang3.ObjectUtils;

import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
/**
 * 学生信息控制器类，用于处理与学生信息相关的界面逻辑和交互。
 */
public class stduentcontroler {
    @FXML
    private TextField Addid;
    @FXML
    private TextField ADDBED;

    @FXML
    private TextField ADDBUILD;

    @FXML
    private TextArea ADDREPAIR;

    @FXML
    private TextField ADDROOM;
    @FXML
    private TextField ADDNAME;
    @FXML
    private TextField ADDSEX;
    @FXML
    private TableColumn<Student, String> BED;

    @FXML
    private TableColumn<Student, String> ID;
    @FXML
    private TableColumn<Student, String> BUILD;
    @FXML
    private TableColumn<Student, String> MASSAGE;

    @FXML
    private TableColumn<Student,String> NAME;

    @FXML
    private TableColumn<Student, String> ROOM;

    @FXML
    private TableColumn<Student, String> SEX;

    @FXML
    private Button choose;

    @FXML
    private Button information;

    @FXML
    private Pagination pagetable;

    @FXML
    private Button repairing;

    @FXML
    private Button search1;
    private List<Student> data;
    private int itempage=16;
    @FXML
    private TableView<Student> tableview;
    private Timestamp initiaupdatetime=Timestamp.valueOf(LocalDateTime.now());
    private  Timestamp lastupdatetime=initiaupdatetime;
    private String[] buildtosex=new String[12];
    /**
     * 初始化楼号和性别的对应关系。
     */
    private void setsex(){
        buildtosex[8]="男";
        buildtosex[9]="女";
        buildtosex[10]="男";
        buildtosex[11]="女";
    }
    /**
     * 处理获取学生信息按钮点击事件。
     * @param event 点击事件
     */
    @FXML
    void getinformation(ActionEvent event) {
        String studentID = Addid.getText();

        // 验证学号不为空
        if (studentID != null && !studentID.isEmpty()) {
            try (Connection connection = DruidDataSourceUtil.getConnection()) {
                studentDAO stDAO = new studentDAO(connection);
                Student student = stDAO.select(studentID);

                // 清空表格视图
                tableview.getItems().clear();

                // 在表格中显示学生信息
                if (student != null) {
                    ADDNAME.setText(student.getNAME());
                    ADDNAME.setDisable(true);
                    ADDSEX.setText(student.getSEX());
                    ADDSEX.setDisable(true);
                    ADDBUILD.setText(student.getBUILD());
                    ADDBUILD.setDisable(true);
                    ADDROOM.setText(student.getROOM());
                    ADDROOM.setDisable(true);
                    ADDBED.setText(student.getBED());
                    ADDBED.setDisable(true);
                    ADDREPAIR.setText(student.getMASSAGE());
                    ObservableList<Student> studentList = FXCollections.observableArrayList(student);
                    updateTableView(studentList);
                } else {
                    settext();
                   showAlert("未找到学生ID为：" + studentID + "的学生");
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        } else {
            settext();
            showAlert("请输入学生ID");
        }
    }
    /**
     * 处理报修按钮点击事件。
     * @param event 点击事件
     */
    @FXML
    void repair(ActionEvent event) {
        try {
            // 从 ADDID 和 ADDREPAIR 获取信息
            String studentID = Addid.getText();
            String newRepairInfo = ADDREPAIR.getText();
            studentDAO studentDAO=new studentDAO(JAVAkeshe.DruidDataSourceUtil.getConnection());
            // 使用学生ID查询对应的学生信息
            Student student = studentDAO.select(studentID);

            if (student != null) {
                // 更新学生实体的报修信息
                student.setMASSAGE(newRepairInfo);
                // 使用学生ID更新数据库中对应的报修信息
                studentDAO.updateByid(student, studentID);
                loadAndRefreshData();
                // 提示更新成功或其他操作
                showAlert("报修信息更新成功！");
            } else {
                // 学生ID不存在，进行错误处理
                showAlert("未找到对应学生ID的报修信息！");
            }
        } catch (SQLException e) {
            e.printStackTrace();

        }
    }
    /**
     * 处理搜索按钮点击事件。
     * @param event 点击事件
     */
    @FXML
    void search(ActionEvent event) {
        String build = ADDBUILD.getText();
        String room = ADDROOM.getText();
        String bed = ADDBED.getText();
        try {
            // 创建 studentDAO 对象
            studentDAO stDAO = new studentDAO(DruidDataSourceUtil.getConnection());

            // 构建查询条件字符串
            StringBuilder conditionsBuilder = new StringBuilder("1=1");

            if (build != null && !build.isEmpty()) {
                conditionsBuilder.append(" AND BUILD = '").append(build).append("'");
            }

            if (room != null && !room.isEmpty()) {
                conditionsBuilder.append(" AND ROOM = '").append(room).append("'");
            }

            if (bed != null && !bed.isEmpty()) {
                conditionsBuilder.append(" AND BED = '").append(bed).append("'");
            }

            // 获取符合条件的学生列表
            List<Student> searchResults = stDAO.selectByCondition(conditionsBuilder.toString());
            // 清空表格视图
            tableview.getItems().clear();
            // 在表格中显示符合条件的学生信息
            if (!searchResults.isEmpty()) {
              stinitpage(searchResults);
              int startindex=0;
              int endindex=Math.min(itempage,searchResults.size());
              ObservableList<Student> students=FXCollections.observableArrayList(searchResults.subList(startindex,endindex));
                tableview.getItems().addAll(students);
            } else {
                // 处理未找到符合条件的学生的情况
                showAlert("未找到符合条件的学生");
            }
        } catch (SQLException e) {
            e.printStackTrace();
            // 处理异常
        }
    }
    /**
     * 处理选择房间按钮点击事件。
     * @param event 点击事件
     */
    @FXML
    void chooseroom(ActionEvent event) {
        String id=Addid.getText();
        String build = ADDBUILD.getText();
        String room = ADDROOM.getText();
        String bed = ADDBED.getText();
        String name=ADDNAME.getText();
        String sex=ADDSEX.getText();
        String massage=ADDREPAIR.getText();
        if(!Objects.equals(sex, buildtosex[Integer.parseInt(build)])){
            showAlert("同一楼号不能出现不同性别");
        }else if (id != null && !id.isEmpty()) {
            try (Connection connection = DruidDataSourceUtil.getConnection()) {
                studentDAO stDAO = new studentDAO(connection);
                Student student = stDAO.select(id);

                // 清空表格视图
                tableview.getItems().clear();

                // 判断学号是否存在
                if (student == null) {
                    //判断床位是否有人
                    try {
                        // 创建 studentDAO 对象
                        studentDAO studentDAO = new studentDAO(DruidDataSourceUtil.getConnection());

                        // 构建查询条件字符串
                        StringBuilder conditionsBuilder = new StringBuilder("1=1");

                        if (build != null && !build.isEmpty()) {
                            conditionsBuilder.append(" AND BUILD = '").append(build).append("'");
                        }

                        if (room != null && !room.isEmpty()) {
                            conditionsBuilder.append(" AND ROOM = '").append(room).append("'");
                        }

                        if (bed != null && !bed.isEmpty()) {
                            conditionsBuilder.append(" AND BED = '").append(bed).append("'");
                        }
                        // 获取符合条件的学生列表
                        List<Student> searchResults = studentDAO.selectByCondition(conditionsBuilder.toString());
                        // 清空表格视图
                        tableview.getItems().clear();

                        //对应床位有人则显示信息
                        if (!searchResults.isEmpty()) {
                            ObservableList<Student> studentList = FXCollections.observableArrayList(searchResults);
                            updateTableView(studentList);
                            System.out.println(studentList);
                            showAlert("床位已经有学生");
                        } else {
                            //反之则插入信息

                            Student newstudent=new Student(id,name,sex,build,room,bed,massage);
                            try (Connection connection1=DruidDataSourceUtil.getConnection()){
                                studentDAO stDao=new studentDAO(connection1);
                                stDao.insert(newstudent);
                            }catch (Exception e){
                                e.printStackTrace();
                            }
                            loadPageData(0);

                        }
                    } catch (SQLException e) {
                        e.printStackTrace();
                        // 处理异常
                    }
                } else {
                    ObservableList<Student> studentList = FXCollections.observableArrayList(student);
                    updateTableView(studentList);
                    showAlert(id + "的学生已存在");
                }
            } catch (Exception e) {
                e.printStackTrace();
                // 处理异常
            }
        } else {
            showAlert("请输入学生ID");
        }
    }
    /**
     * 初始化方法，用于设置页面初始状态。
     * @throws Exception 初始化异常
     */
    @FXML
    private void initialize() throws Exception{
// 使用学生数据更新TableView
        setsex();
        initializepage();
        loadPageData(0);
        startPollingst();
    }
    /**
     * 设置分页操作
     * @param students 学生表
     */
    private void stinitpage(List<Student> students) {
        int pagecount = (int) Math.ceil((double) students.size() / itempage);
        pagetable.setPageCount(pagecount);
        pagetable.currentPageIndexProperty().addListener((observable, oldValue, newValue) -> {
            int page = newValue.intValue();
            int startIndex = page * itempage;
            System.out.println(startIndex);
            int endIndex = Math.min((page+1) * itempage, students.size());
            System.out.println(endIndex);
            // 获取当前页的学生数据
            if(startIndex<=endIndex&&startIndex<students.size()){
                List<Student> list=students.subList(startIndex,endIndex);
                System.out.println(list);
                tableview.getItems().clear();
                tableview.getItems().addAll(list);
                tableview.refresh();
            }
        });
    }
    /**
     * 初始化方法，用于设置页面初始状态。
     */
    void settext(){
        ADDNAME.setText(null);
        ADDNAME.setDisable(false);
        ADDSEX.setText(null);
        ADDSEX.setDisable(false);
        ADDBUILD.setText(null);
        ADDBUILD.setDisable(false);
        ADDROOM.setText(null);
        ADDROOM.setDisable(false);
        ADDBED.setText(null);
        ADDBED.setDisable(false);
        ADDREPAIR.setText(null);
    }
    /**
     * 初始化分页相关设置，包括设置页面数量和监听页面切换事件
     */
    private void initializepage(){
        pagetable.setPageCount(CalculatepageCount());
        pagetable.currentPageIndexProperty().addListener((observable, oldValue, newValue) -> {
            loadPageData(newValue.intValue());
        });
    }
    /**
     * 计算总页数
     * @return 总页数
     */
    private int CalculatepageCount(){
        try (Connection connection=DruidDataSourceUtil.getConnection()){
            studentDAO stDao=new studentDAO(connection);
            return(int)Math.ceil((double) stDao.gettotalRecords()/itempage);

        }catch (Exception e){
            e.printStackTrace();
        }
        return 0;
    }
    /**
     * 加载指定页码的数据
     *
     * @param pageindex 页码
     */
    private void loadPageData(int pageindex) {
        try (Connection connection = DruidDataSourceUtil.getConnection()) {
            studentDAO stDAO = new studentDAO(connection);
            List<Student> pageData = stDAO.selectPaged(pageindex, itempage);
            updateTableView(pageData);
        }catch (Exception e){
            e.printStackTrace();
        }
    }
    /**
     * 更新TableView显示的数据
     *
     * @param students 学生数据列表
     */
    private void updateTableView(List<Student> students) {

        tableview.getItems().setAll(students);
// 为每列设置单元格值工厂，以从学生对象中获取属性值显示。
        ID.setCellValueFactory(new PropertyValueFactory<>
                ("ID"));
        NAME.setCellValueFactory(new PropertyValueFactory<>
                ("NAME"));
        SEX.setCellValueFactory(new PropertyValueFactory<>
                ("SEX"));
        BUILD.setCellValueFactory(new PropertyValueFactory<>
                ("BUILD"));
        ROOM.setCellValueFactory(new PropertyValueFactory<>
                ("ROOM"));
        BED.setCellValueFactory(new PropertyValueFactory<>
                ("BED"));
        MASSAGE.setCellValueFactory(new PropertyValueFactory<>
                ("MASSAGE"));
    }
    /**
     * 加载全部数据
     *
     * @return 学生数据列表
     */
    private List<Student> loadData()  {
        try (Connection conn = DruidDataSourceUtil.getConnection()) {// 获取

// 创建学生数据访问对象
            studentDAO studentDAO  = new studentDAO(conn);
// 从数据库中查询所有学生数据
            return studentDAO.selectAll();
        } catch (Exception e) {
// 异常处理，打印异常信息
            e.printStackTrace();
// 返回空列表表示加载数据失败
            return null;
        }
    }
    /**
     * 加载并刷新数据
     */
    private void loadAndRefreshData() {
        try {
            // 重新加载数据
            List<Student> students = loadData();

            // 更新 TableView
            updateTableView(students);
        } catch (Exception e) {
            e.printStackTrace();
            // 处理异常
        }
    }
    /**
     * 启动轮询更新数据的线程
     */
    private void startPollingst() {
// 创建一个新的任务，用于在后台线程中执行数据轮询逻辑
        Runnable dataPollingTask = () -> {
            while (true) {
// 检查是否有新的数据更新
                if (sthasNewUpdate()) {
// 如果检测到新的更新，刷新用户界面
                    refreshUI();
// 更新初始的更新时间，用于跟踪数据更新的时间戳
                    initiaupdatetime = lastupdatetime;
                }
                try {
// 休眠5秒钟后再次检查是否有新的数据更新
                    Thread.sleep(5000); // 休眠5秒钟（5000毫秒）
                } catch (InterruptedException e) {
                    e.printStackTrace(); // 如果线程被中断，打印异常堆栈信息
                }
            }
        };
// 创建一个新的线程执行上面定义的任务
        Thread dataPollingThread = new Thread(dataPollingTask);
// 设置该线程为守护线程，当应用关闭时，该线程会自动结束，不会阻止应用退出
        dataPollingThread.setDaemon(true);
// 启动新创建的线程来执行数据轮询任务
        dataPollingThread.start();
    }
    // 判断是否有新的更新
    /**
     * 判断是否有新的更新
     *
     * @return 是否有新的更新
     */
    private boolean sthasNewUpdate() {
// 从数据库服务中获取最新的更新时间
        try (Connection connection = DruidDataSourceUtil.getConnection()) {
            studentDAO studentDAO = new studentDAO(connection);
            lastupdatetime = studentDAO.getUpdateTime();
// 判断获取到的最新更新时间是否不为空，并且与初始的更新时间不同
            return lastupdatetime != null && !lastupdatetime.equals(initiaupdatetime);

        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }
    /**
     * 刷新UI的方法
     */
    private void refreshUI() {
// 使用JavaFX的Platform.runLater方法来确保UI更新的线程安全
        Platform.runLater(() -> {
// 加载当前页面的数据
            loadPageData(pagetable.getCurrentPageIndex());
        });
    }
    /**
     * 显示提示消息
     *
     * @param message 提示消息内容
     */
    private void showAlert(String message) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle("提示");
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }

}
