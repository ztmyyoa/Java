package JAVAkeshe;

/**
 * 项目运行主类
 */
public class MAIN {
    public static void main(String[] args) {
        loginview.main(args);
    }
}
