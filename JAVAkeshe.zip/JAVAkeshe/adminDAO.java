package JAVAkeshe;


import java.sql.*;
import java.util.ArrayList;
import java.util.List;
/**
 * 数据访问对象（DAO）实现类，用于操作管理员信息表（administrator）。
 */
public class adminDAO implements JDBCO<administrator,String>{
    // SQL语句用于在管理员信息表中插入一条记录
    private final String insert = "INSERT INTO administrator (ID, NAME,SEX,BUILD,PHONE) VALUES (?, ?, ?, ?, ?)";
    private final String update1 ="UPDATE administrator SET NAME=?,SEX=? ,BUILD=?, PHONE=? WHERE ID=?";
    private final String delete="DELETE FROM administrator WHERE ID=?";
    public adminDAO(Connection connection){

    }
    /**
     * 向管理员信息表中插入一条记录。
     *
     * @param entity 要插入的管理员对象
     * @throws SQLException 如果数据库操作发生错误
     */
    @Override
    public void insert(administrator entity) throws SQLException {

        try(Connection connection= DruidDataSourceUtil.getConnection();
            PreparedStatement preparedStatement=connection.prepareStatement(insert)){
            preparedStatement.setString(1,entity.getID());
            preparedStatement.setString(2,entity.getNAME());
            preparedStatement.setString(3,entity.getSEX());
            preparedStatement.setString(4,entity.getBUILD());
            preparedStatement.setString(5,entity.getPHONE());
            preparedStatement.executeUpdate();
        }
    }

    @Override
    public void insertBatch(List<administrator> entities) throws SQLException {

    }
    /**
     * 根据管理员ID更新管理员信息。
     *
     * @param entity   包含更新数据的管理员对象
     * @param key      要更新的管理员ID
     * @throws SQLException 如果数据库操作发生错误
     */
    @Override
    public void updateByid(administrator entity, String key) throws SQLException {
        String updateQuery = "UPDATE administrator SET NAME=?, SEX=?, BUILD=?, PHONE=? WHERE ID=?";

        try (Connection connection = DruidDataSourceUtil.getConnection();
             PreparedStatement preparedStatement = connection.prepareStatement(updateQuery)) {

            // 设置更新语句中的参数
            preparedStatement.setString(1, entity.getNAME());
            preparedStatement.setString(2, entity.getSEX());
            preparedStatement.setString(3, entity.getBUILD());
            preparedStatement.setString(4, entity.getPHONE());
            preparedStatement.setString(5, key);  // 使用学生ID作为更新的条件

            // 执行更新操作
            preparedStatement.executeUpdate();
        }
    }

    @Override
    public void updateByCondition(String condition, Object[] params, administrator entity) throws SQLException {

    }

    @Override
    public void delete(String primaryKey) throws SQLException {

    }

    @Override
    public void deleteBatch(List<String> primaryKeys) throws SQLException {

    }

    @Override
    public void deleteByCondition(String condition, Object[] params) throws SQLException {

    }
    /**
     * 根据管理员ID查询单个管理员信息。
     *
     * @param primaryKey 要查询的管理员ID
     * @return 如果存在匹配的管理员信息，则返回相应的管理员对象；否则返回 null。
     * @throws SQLException 如果数据库操作发生错误
     */
    @Override
    public administrator select(String primaryKey) throws SQLException {
        administrator administrator=null;
        try(Connection connection=DruidDataSourceUtil.getConnection();
        PreparedStatement preparedStatement=connection.prepareStatement("SELECT * FROM administrator WHERE ID = ?");){
            preparedStatement.setString(1, primaryKey);

            try (ResultSet resultSet = preparedStatement.executeQuery()) {
                if (resultSet.next()) {
                    administrator = new administrator();
                    administrator.setID(resultSet.getString("ID"));
                    administrator.setNAME(resultSet.getString("NAME"));
                    administrator.setSEX(resultSet.getString("SEX"));
                    administrator.setBUILD(resultSet.getString("BUILD"));
                    administrator.setPHONE(resultSet.getString("PHONE"));
                }
            }
        }
        return administrator;
    }
    /**
     * 查询所有管理员信息。
     *
     * @return 包含所有管理员信息的列表。如果没有管理员信息，则返回空列表。
     * @throws SQLException 如果数据库操作发生错误
     */
    @Override
    public List<administrator> selectAll() throws SQLException {
        List<administrator> administrators=new ArrayList<>();
        try (Connection connection = DruidDataSourceUtil.getConnection();
             PreparedStatement preparedStatement = connection.prepareStatement("SELECT * FROM administrator");
             ResultSet resultSet = preparedStatement.executeQuery()) {
            while (resultSet.next()) {
                administrator administrator = new administrator();
                administrator.setID(resultSet.getString("ID"));
                administrator.setNAME(resultSet.getString("NAME"));
                administrator.setSEX(resultSet.getString("SEX"));
                administrator.setBUILD(resultSet.getString("BUILD"));
                administrator.setPHONE(resultSet.getString("PHONE"));
                administrators.add(administrator);
            }
        }
        return administrators;
    }
    /**
     * 根据指定条件查询管理员信息。
     *
     * @param conditions 查询条件，可以是 SQL WHERE 子句的一部分。
     * @return 包含符合条件的管理员信息的列表。如果没有匹配的管理员信息，则返回空列表。
     * @throws SQLException 如果数据库操作发生错误
     */
    @Override
    public List<administrator> selectByCondition(String conditions) throws SQLException {
        List<administrator> administrators =new ArrayList<>();
        String query="SELECT * FROM administrator WHERE " + conditions;
        try (Connection connection = DruidDataSourceUtil.getConnection();
             PreparedStatement statement = connection.prepareStatement(query);
             ResultSet resultSet = statement.executeQuery()) {
            System.out.println("SQL Query: " + query);
            while (resultSet.next()) {
                administrator administrator = new administrator(
                        resultSet.getString("ID"),
                        resultSet.getString("NAME"),
                        resultSet.getString("SEX"),
                        resultSet.getString("BUILD"),
                        resultSet.getString("PHONE")
                );
                administrators.add(administrator);
            }
        }

        return administrators;
    }
    /**
     * 将 ResultSet 中的数据映射为 Administrator 实体对象。
     *
     * @param resultSet 包含查询结果的 ResultSet 对象。
     * @return 映射后的 Administrator 实体对象。
     * @throws SQLException 如果操作数据库时发生错误。
     */
    private administrator mapResultSetToEntity(ResultSet resultSet) throws SQLException {
        administrator administrator = new administrator();
        administrator.setID(resultSet.getString("ID"));
        administrator.setNAME(resultSet.getString("NAME"));
        administrator.setSEX(resultSet.getString("SEX"));
        administrator.setBUILD(resultSet.getString("BUILD"));
        administrator.setPHONE(resultSet.getString("PHONE"));
        return administrator;
    }
    /**
     * 分页查询管理员信息。
     *
     * @param page     当前页数，从 0 开始。
     * @param pagesize 每页显示的记录数。
     * @return 包含分页查询结果的 Administrator 实体对象列表。
     * @throws SQLException 如果操作数据库时发生错误。
     */
    @Override
    public List<administrator> selectPaged(int page, int pagesize) throws SQLException {
        List<administrator> administrators = new ArrayList<>();
        String select="SELECT*FROM administrator LIMIT ?,?";
        try(Connection connection=DruidDataSourceUtil.getConnection();
        PreparedStatement preparedStatement=connection.prepareStatement(select)){
            preparedStatement.setInt(1,page*pagesize);
            preparedStatement.setInt(2,pagesize);
            try(ResultSet resultSet=preparedStatement.executeQuery()){
                while(resultSet.next()){
                    administrators.add(mapResultSetToEntity(resultSet));
                }
            }
        }
        return administrators;
    }
    /**
     * 统计特定楼栋的管理员数量。
     *
     * @param building 指定的楼栋名称。
     * @return 特定楼栋的管理员数量。
     * @throws SQLException 如果操作数据库时发生错误。
     */
    @Override
    public int countStudentsByBuilding(String building) throws SQLException {
        int count = 0;
        String sql = "SELECT COUNT(*) FROM administrator WHERE BUILD = ?";

        try (Connection connection=DruidDataSourceUtil.getConnection();
             PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setString(1, building);

            try (ResultSet resultSet = statement.executeQuery()) {
                if (resultSet.next()) {
                    count = resultSet.getInt(1);
                }
            }
        }

        return count;
    }
    /**
     * 获取管理员总记录数。
     *
     * @return 管理员表中的总记录数。
     * @throws Exception 如果操作数据库时发生错误。
     */
    @Override
    public int gettotalRecords() throws Exception {
        String sql="SELECT COUNT(*) FROM administrator";
        try(Connection connection=DruidDataSourceUtil.getConnection();
        PreparedStatement preparedStatement=connection.prepareStatement(sql);
        ResultSet rs=preparedStatement.executeQuery()){
            if(rs.next()){
                return rs.getInt(1);
            }
        }
        return 0;
    }

    /**
     * 获取管理员信息更新的时间戳。
     *
     * @return 更新管理员信息的时间戳。
     * @throws SQLException 如果操作数据库时发生错误。
     */
    public Timestamp getUpdateTime() throws SQLException {
        String sql = "SELECT * FROM update_ad WHERE id = 1";
        try (Connection connection=DruidDataSourceUtil.getConnection();
             PreparedStatement preparedStatement = connection.prepareStatement(sql))
        {
            ResultSet rs = preparedStatement.executeQuery();
            if (rs.next()) {
                return rs.getTimestamp("updatetime");
            }
            return null;
        }
    }
}
