package JAVAkeshe;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import java.sql.Date;
/**
 * 登录用户类
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
public class user {
    //用户名
    private String username;
    //密码
    private String password;

    private String build;
}
