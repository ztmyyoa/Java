package JAVAkeshe;


import com.alibaba.excel.annotation.ExcelProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.sql.Date;

/**
 * 学生宿舍的信息类
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
public class Student {
    @ExcelProperty("ID")
    private String ID;
    @ExcelProperty("姓名")
    private String NAME;
    @ExcelProperty("性别")
    private String SEX;
    @ExcelProperty("楼号")
    private  String BUILD;
    @ExcelProperty("宿舍")
    private String ROOM;
    @ExcelProperty("床位")
    private String BED;
    @ExcelProperty("报修信息")
    private String MASSAGE;

    }

