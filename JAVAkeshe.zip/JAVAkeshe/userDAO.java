package JAVAkeshe;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

/**
 * 用户数据访问对象类，实现了JDBCO接口
 */
public class userDAO implements JDBCO<user, String> {
    private final String insert = "INSERT INTO user1 (username, password, BUILD) VALUES (?, ?, ?)";
    private final String updateQuery = "UPDATE user1 SET password=?, BUILD=? WHERE username=?";
    private final String select = "SELECT * FROM user1 WHERE username = ?";

    public userDAO(Connection connection) {
        // Constructor
    }

    /**
     * 插入用户信息到数据库
     *
     * @param entity 用户实体对象
     * @throws SQLException SQL异常
     */
    @Override
    public void insert(user entity) throws SQLException {
        try (Connection connection = DruidDataSourceUtil.getConnection();
             PreparedStatement preparedStatement = connection.prepareStatement(insert)) {
            preparedStatement.setString(1, entity.getUsername());
            preparedStatement.setString(2, entity.getPassword());
            preparedStatement.setString(3, entity.getBuild());
            preparedStatement.executeUpdate();
        }
    }

    /**
     * 更新用户信息通过用户名
     *
     * @param entity 用户实体对象
     * @param key    用户名
     * @throws SQLException SQL异常
     */
    @Override
    public void updateByid(user entity, String key) throws SQLException {
        try (Connection connection = DruidDataSourceUtil.getConnection();
             PreparedStatement preparedStatement = connection.prepareStatement(updateQuery)) {
            // 设置更新语句中的参数
            preparedStatement.setString(1, entity.getPassword());
            preparedStatement.setString(2, entity.getBuild());
            preparedStatement.setString(3, key);  // 使用用户名作为更新的条件

            // 执行更新操作
            preparedStatement.executeUpdate();
        }
    }

    /**
     * 从ResultSet映射用户实体对象
     *
     * @param resultSet 查询结果集
     * @return 用户实体对象
     * @throws SQLException SQL异常
     */
    private user mapResultSetToEntity(ResultSet resultSet) throws SQLException {
        user user = new user();
        user.setUsername(resultSet.getString("username"));
        user.setPassword(resultSet.getString("password"));
        user.setBuild(resultSet.getString("BUILD"));
        return user;
    }

    /**
     * 通过用户名查询用户信息
     *
     * @param primaryKey 用户名
     * @return 用户实体对象
     * @throws SQLException SQL异常
     */
    @Override
    public user select(String primaryKey) throws SQLException {
        user user1 = null;
        try (Connection connection = DruidDataSourceUtil.getConnection();
             PreparedStatement preparedStatement = connection.prepareStatement(select)) {
            preparedStatement.setString(1, primaryKey);
            try (ResultSet resultSet = preparedStatement.executeQuery()) {
                if (resultSet.next()) {
                    user1 = mapResultSetToEntity(resultSet);
                }
            }
        }
        return user1;
    }

    @Override
    public void insertBatch(List<user> entities) throws SQLException {

    }
    @Override
    public void updateByCondition(String condition, Object[] params, user entity) throws SQLException {

    }

    @Override
    public void delete(String primaryKey) throws SQLException {

    }

    @Override
    public void deleteBatch(List<String> primaryKeys) throws SQLException {

    }

    @Override
    public void deleteByCondition(String condition, Object[] params) throws SQLException {

    }
    @Override
    public List<user> selectAll() throws SQLException {
        return null;
    }

    @Override
    public List<user> selectByCondition(String conditions) throws SQLException {
        return null;
    }

    @Override
    public List<user> selectPaged(int page, int pagesize) throws SQLException {
        return null;
    }

    @Override
    public int countStudentsByBuilding(String building) throws SQLException {
        return 0;
    }

    @Override
    public int gettotalRecords() throws Exception {
        return 0;
    }
}
