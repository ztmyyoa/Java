package JAVAkeshe;

import com.alibaba.excel.context.AnalysisContext;
import com.alibaba.excel.event.AnalysisEventListener;

import java.util.List;
/**
 * Excel数据解析监听器，用于解析Excel文件中的学生数据并将其存储到指定的数据列表中。
 */
public class ExcelListener extends AnalysisEventListener<Student> {

    private List<Student> dataList;
    /**
     * 构造方法，接收一个数据列表用于存储解析后的学生数据。
     *
     * @param dataList 用于存储解析后学生数据的列表
     */
    public ExcelListener(List<Student> dataList) {
        this.dataList = dataList;
    }
    /**
     * 解析Excel文件中的一行数据时调用的方法，将解析的数据添加到数据列表中。
     *
     * @param data    解析得到的学生数据对象
     * @param context 解析上下文
     */
    @Override
    public void invoke(Student data, AnalysisContext context) {
        dataList.add(data);
    }
    /**
     * 在所有数据解析完成后调用的方法，可以进行一些清理工作。
     *
     * @param context 解析上下文
     */
    @Override
    public void doAfterAllAnalysed(AnalysisContext context) {
        // Do something after all data is analyzed
    }
}
